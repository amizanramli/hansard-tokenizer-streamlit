# bm_spacy_pipeline.py
from pathlib import Path

import spacy
from spacy.language import Language
from spacy.tokens import Token

from .stemmer import lemma_stem, root_stem


# --- 1. Token extensions ---

# root: akar kata (distinct from lemma)
Token.set_extension("root", default=None, force=True)


# --- 2. Component: clitic splitter (optional) ---

CLITIC_SUFFIXES = ("lah", "kah", "tah", "pun", "nya", "ku", "mu")


@Language.component("bm_clitic_splitter")
def bm_clitic_splitter(doc):
    """
    Split common Malay enclitics and particles from word stems, e.g.:

        hatiku     ->  hati   + ku
        rumahnya   ->  rumah  + nya
        buatlah    ->  buat   + lah
        apakah     ->  apa    + kah

    For spaCy 3.8.x, Retokenizer.split requires 'heads' as a list of
    Token or (Token, subtoken_index) tuples. Here we simply attach
    both new subtokens to the original token, which is fine since
    we're not using a parser yet.
    """
    with doc.retokenize() as retok:
        # Work on a copy of the tokens because we'll be modifying doc
        for token in list(doc):
            text = token.text
            lower = text.lower()

            # Only consider alphabetic tokens without hyphens for clitic splitting
            if not token.is_alpha or "-" in text:
                continue

            # Try longer suffixes first so 'nya' isn't eaten after something longer, etc.
            for suf in sorted(CLITIC_SUFFIXES, key=len, reverse=True):
                if lower.endswith(suf) and len(text) > len(suf) + 1:
                    stem = text[: len(text) - len(suf)]
                    clitic = text[len(text) - len(suf):]

                    # spaCy 3.8: heads = list of Tokens or (Token, subtoken_index)
                    # Attach both new tokens to the original token.
                    heads = [token, token]

                    retok.split(token, [stem, clitic], heads=heads)
                    break

    return doc



# --- 3. Component: merge hyphenated words (buku-buku, pukul-memukul, etc.) ---

@Language.component("bm_hyphen_merger")
def bm_hyphen_merger(doc):
    """
    Merge simple hyphenated alpha sequences into single tokens:
        buku - buku     -> "buku-buku"
        pukul - memukul -> "pukul-memukul"

    This allows our stemmer to see the whole reduplicated form.
    """
    with doc.retokenize() as retok:
        i = 0
        while i < len(doc) - 2:
            t1, t2, t3 = doc[i], doc[i + 1], doc[i + 2]
            if t1.is_alpha and t2.text == "-" and t3.is_alpha:
                span = doc[i : i + 3]
                retok.merge(span)
                i += 1
            else:
                i += 1
    return doc


# --- 4. Component: apply Malay lemma + root from our stemmer ---

@Language.component("bm_morph_annotator")
def bm_morph_annotator(doc):
    """
    Annotate each token with:
      - token.lemma_ : lemma-style stem (dictionary-like)
      - token._.root : akar kata (with productive reduplication collapsed)
    """
    for tok in doc:
        text = tok.text
        tok.lemma_ = lemma_stem(text)
        tok._.root = root_stem(text)
    return doc


# --- 5. Factory: create a Malay spaCy pipeline ---

def create_bm_nlp(split_clitics: bool = False) -> spacy.language.Language:
    """
    Create a lightweight Malay spaCy pipeline.
    """
    import re
    from spacy.tokenizer import Tokenizer
    from spacy.util import compile_infix_regex

    nlp = spacy.blank("xx")
    nlp.lang = "ms"  # metadata only

    # Split adjacent legal/list references such as:
    #   (2)(a)      -> ( 2 ) ( a )
    #   (1)(a)(ii) -> ( 1 ) ( a ) ( ii )
    #
    # spaCy already handles simple "(2)", but without this infix rule
    # it may keep the middle part as "2)(a".
    
    infixes = list(nlp.Defaults.infixes)
    infixes.extend([
        r"(?<=\))(?=\()",          # split BETWEEN ) and (
        r"(?<=[0-9A-Za-z])\)",    # split before closing bracket
        r"\((?=[0-9A-Za-z])",     # split after opening bracket
    ])

    infix_re = compile_infix_regex(infixes)

    nlp.tokenizer = Tokenizer(
        nlp.vocab,
        rules=nlp.Defaults.tokenizer_exceptions,
        prefix_search=nlp.tokenizer.prefix_search,
        suffix_search=nlp.tokenizer.suffix_search,
        infix_finditer=infix_re.finditer,
        token_match=nlp.tokenizer.token_match,
    )

    # Always merge hyphenated sequences first
    nlp.add_pipe("bm_hyphen_merger", first=True)

    # Optionally split clitics AFTER hyphen merging
    if split_clitics:
        nlp.add_pipe("bm_clitic_splitter")

    # Finally, annotate lemma and root
    nlp.add_pipe("bm_morph_annotator", last=True)

    return nlp



# --- 6. Convenience loader for Prodigy / scripts ---

def load():
    """
    Convenience function so external tools (e.g., Prodigy) can do:
        from bm_spacy_pipeline import load
        nlp = load()
    """
    return create_bm_nlp(split_clitics=False)


# --- 7. Simple manual test ---

if __name__ == "__main__":
    nlp = create_bm_nlp(split_clitics=True)

    text = (
        "Dia membaca buku-buku di rumahku, "
        "lalu memukul-memukul meja itu. "
        "Hatiku dan hatinya belum tenang."
    )

    doc = nlp(text)

    print("\nTEXT\t\tLEMMA\t\tROOT")
    print("-" * 40)
    for tok in doc:
        print(f"{tok.text:<15}{tok.lemma_:<15}{tok._.root}")
