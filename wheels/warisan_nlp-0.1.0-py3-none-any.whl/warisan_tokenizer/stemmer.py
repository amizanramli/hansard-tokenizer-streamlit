import sys
from pathlib import Path
from importlib.resources import files

# --- 1. Configuration & Lexicon Loading ---

KATA_AKAR_FILE = "kata_akar.txt"
EXCEPTIONS_REDUP_FILE = "exceptions_redup.txt"

KATA_AKAR_SET = set()
REDUP_EXCEPTIONS = {}  # surface -> root (for root mode)


def load_lexicon(path=KATA_AKAR_FILE):
    """
    Load kata_akar.txt from the installed package data directory:
        warisan_tokenizer/data/kata_akar.txt
    """
    try:
        lexicon_file = files("warisan_tokenizer").joinpath("data", path)

        with lexicon_file.open("r", encoding="utf-8") as f:
            return set(line.strip() for line in f if line.strip())

    except FileNotFoundError:
        print(
            f"Error: Lexicon file not found in package data: data/{path}",
            file=sys.stderr,
        )
        return set()


def load_redup_exceptions(path=EXCEPTIONS_REDUP_FILE):
    """
    Load reduplication exceptions from a tab-separated file, if present.

    Format per line:
        surface<TAB>root

    Examples:
        ajar-ajar\tajar-ajar   # DO NOT collapse even in root mode
        ajar-ajar\tajar        # Force root_stem('ajar-ajar') -> 'ajar'

    If the file doesn't exist, returns an empty dict.
    """
    base = Path(__file__).resolve().parent
    full_path = base / path
    if not full_path.exists():
        return {}
    mapping = {}
    with open(full_path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            parts = ln.split("\t")
            if len(parts) == 1:
                surface = parts[0].strip()
                root = surface
            else:
                surface = parts[0].strip()
                root = parts[1].strip()
            if surface:
                mapping[surface.lower()] = root.lower()
    return mapping


# --- 2. Stemming Steps (shared by lemma & root modes) ---

def _step_1_reduplication(word, mode, original_word, is_recursive_call):
    """
    Step 1 / Step 6: Reduplication handling.

    - If mode == "lemma": DO NOT change the surface form for hyphenated words.
      (e.g., 'ajar-ajar' stays 'ajar-ajar', 'buku-buku' stays 'buku-buku')
    - If mode == "root":
        1) Check exceptions list (REDUP_EXCEPTIONS).
        2) Otherwise, collapse productive reduplication:
           * A-A -> A (if A is in lexicon)
           * A-B where root(A) == root(B) -> that root

    For recursive calls (is_recursive_call=True), this step is skipped to avoid loops.
    """
    # No reduplication or we are already recursing -> no-op
    if "-" not in word or is_recursive_call:
        return word

    if mode == "lemma":
        # Keep lexical/lemma form intact
        return original_word

    # mode == "root": first, check explicit exceptions
    lower = original_word.lower()
    if lower in REDUP_EXCEPTIONS:
        # Use the override root (can be same as surface if you want no collapse)
        return REDUP_EXCEPTIONS[lower]

    # Otherwise, attempt productive reduplication analysis
    parts = word.split("-")
    if len(parts) != 2:
        return original_word

    part1, part2 = parts[0], parts[1]

    # Recursively compute roots of each part (but don't re-enter redup logic)
    r1 = _stem_engine(part1, mode=mode, is_recursive_call=True)
    r2 = _stem_engine(part2, mode=mode, is_recursive_call=True)

    # Productive reduplication: both parts share the same root in lexicon
    if r1 == r2 and r1 in KATA_AKAR_SET:
        return r1

    # Otherwise, treat as lexicalised/unknown redup; keep lemma as-is
    return original_word


def _step_2_strip_particles(word):
    """
    Step 2: Remove particles (-lah, -kah, -tah, -pun)
    """
    if word.endswith(("kah", "lah", "tah", "pun")):
        return word[:-3]
    return word


def _step_3_strip_possessives(word):
    """
    Step 3: Remove possessives (-ku, -mu, -nya, -nda)
    """
    if word.endswith("nya"):
        return word[:-3]
    if word.endswith(("ku", "mu", "nda")):
        if word.endswith("nda"):
            return word[:-3]
        return word[:-2]
    return word


def _step_4_strip_suffixes(word):
    """
    Step 4: Remove suffixes
    (-kan, -i, -an, -wan, -man, -wati, -wi, -wiah)

    Returns:
        (stem_candidate, suffix_was_stripped)
    """
    # High-confidence derivations
    if word.endswith("wati"):
        return word[:-4], True
    if word.endswith("wiah"):
        return word[:-4], True
    if word.endswith("wan") or word.endswith("man"):
        return word[:-3], True
    if word.endswith("wi"):
        return word[:-2], True

    # Productive suffixes (lexicon checked later)
    if word.endswith("kan"):
        return word[:-3], True
    if word.endswith("i"):
        return word[:-1], True
    if word.endswith("an"):
        return word[:-2], True

    return word, False


def _step_5a_strip_simple_prefixes(word):
    """
    Step 5A: simple prefixes (di-, ke-, se-, ber-, ter-, per-).
    Conservative: only accept if the candidate is in the lexicon.
    """
    SIMPLE_PREFIXES = ("ber", "ter", "per", "di", "ke", "se")
    for pref in SIMPLE_PREFIXES:
        if word.startswith(pref) and len(word) > len(pref) + 1:
            cand = word[len(pref):]
            if cand in KATA_AKAR_SET:
                return cand, True
    return word, False


def _step_5b_strip_men(word):
    """
    Step 5B: meN- allomorphs with restoration (conservative; lexicon-checked).
    Coverage:
      - menyV-  -> sV-
      - men{c,d,j,z}- -> strip 'men-'
      - men + other -> t + ...
      - mem{b,f,v}- -> strip 'mem-'
      - mem + other -> p + ...
      - meng + vowel -> strip 'meng-'
      - meng + k...  -> try (drop k) and (keep k)
      - me{l,r,w,y}- -> strip 'me-'
    """
    s = word
    L = s.lower()
    cands = []

    # meny + vowel => s + V...
    if L.startswith("meny") and len(L) > 4:
        rest = s[4:]
        if rest and rest[0].lower() in "aeiou":
            cands.append("s" + rest)   # menyapu -> sapu
            cands.append(rest)

    # men + {c,d,j,z}
    if L.startswith("men") and len(L) > 3:
        rest = s[3:]
        if rest and rest[0].lower() in "cdjz":
            cands.append(rest)         # mencari -> cari
        else:
            cands.append("t" + rest)   # menutup -> tutup

    # mem + {b,f,v}
    if L.startswith("mem") and len(L) > 3:
        rest = s[3:]
        if rest and rest[0].lower() in "bfv":
            cands.append(rest)         # membeli -> beli
        else:
            cands.append("p" + rest)   # memukul -> pukul

    # meng-
    if L.startswith("meng") and len(L) > 4:
        rest = s[4:]
        if rest:
            if rest[0].lower() in "aeiou":
                cands.append(rest)     # mengambil -> ambil
            elif rest[0].lower() == "k":
                cands.append(rest[1:]) # mengkritik -> kritik
                cands.append(rest)
            else:
                cands.append(rest)     # menghitung -> hitung

    # me + {l,r,w,y}
    if L.startswith("me") and len(L) > 2:
        rest = s[2:]
        if rest and rest[0].lower() in "lrwy":
            cands.append(rest)         # melihat -> lihat

    for cand in cands:
        if cand.lower() in KATA_AKAR_SET:
            return cand.lower(), True

    return word, False


def _step_5c_strip_pen(word):
    """
    Step 5C: peN- allomorphs with restoration (conservative; lexicon-checked).
    Coverage:
      - penyV-  -> sV-
      - pen{c,d,j,z}- -> strip 'pen-'
      - pen + other -> t + ...
      - pem{b,f,v}- -> strip 'pem-'
      - pem + other -> p + ...
      - peng + vowel -> strip 'peng-'
      - peng + k...  -> try (drop k) and (keep k)
      - pe{l,r,w,y}- -> strip 'pe-'
    """
    s = word
    L = s.lower()
    cands = []

    # peny + vowel => s + V...
    if L.startswith("peny") and len(L) > 4:
        rest = s[4:]
        if rest and rest[0].lower() in "aeiou":
            cands.append("s" + rest)   # penyapu -> sapu
            cands.append(rest)

    # pen + {c,d,j,z}
    if L.startswith("pen") and len(L) > 3:
        rest = s[3:]
        if rest and rest[0].lower() in "cdjz":
            cands.append(rest)         # pencari -> cari
        else:
            cands.append("t" + rest)   # penutup -> tutup

    # pem + {b,f,v}
    if L.startswith("pem") and len(L) > 3:
        rest = s[3:]
        if rest and rest[0].lower() in "bfv":
            cands.append(rest)         # pembaca -> baca
        else:
            cands.append("p" + rest)   # pemukul -> pukul (if exists)

    # peng-
    if L.startswith("peng") and len(L) > 4:
        rest = s[4:]
        if rest:
            if rest[0].lower() in "aeiou":
                cands.append(rest)     # pengguna -> guna
            elif rest[0].lower() == "k":
                cands.append(rest[1:]) # pengkritik -> kritik
                cands.append(rest)
            else:
                cands.append(rest)     # penggal, etc.

    # pe + {l,r,w,y}
    if L.startswith("pe") and len(L) > 2:
        rest = s[2:]
        if rest and rest[0].lower() in "lrwy":
            cands.append(rest)         # pelari -> lari

    for cand in cands:
        if cand.lower() in KATA_AKAR_SET:
            return cand.lower(), True

    return word, False


# --- 3. Core Engine (shared) ---

def _stem_engine(word, mode="lemma", is_recursive_call=False):
    """
    Core engine shared by lemma_stem and root_stem.

    mode:
      - "lemma": dictionary-like lemma, keeps redup hyphens intact.
      - "root" : akar kata, collapses productive reduplication.
    """
    if not KATA_AKAR_SET:
        if not is_recursive_call:
            print("Error: Lexicon is not loaded. Cannot stem.", file=sys.stderr)
        return word

    original_word = word
    word = word.lower()

    # Lemma mode: preserve all hyphenated forms as lexical forms.
    # This prevents later prefix/suffix logic from changing forms like
    # "berlari-lari" -> "lari-lari".
    if mode == "lemma" and "-" in word and not is_recursive_call:
        return original_word

    # Step 0: direct lexicon hit
    if word in KATA_AKAR_SET:
        return word

    # Step 1 / 6: reduplication (mode-dependent)
    word_after_redup = _step_1_reduplication(word, mode, original_word, is_recursive_call)
    if word_after_redup != word:
        word = word_after_redup
        if word in KATA_AKAR_SET:
            return word

    # Step 2: particles
    stem_candidate = _step_2_strip_particles(word)
    if stem_candidate != word:
        if stem_candidate in KATA_AKAR_SET:
            return stem_candidate
        word = stem_candidate

    # Step 3: possessives
    stem_candidate = _step_3_strip_possessives(word)
    if stem_candidate != word:
        if stem_candidate in KATA_AKAR_SET:
            return stem_candidate
        word = stem_candidate

    # Try meN- before suffix stripping (verbs like 'membeli')
    stem_men_first, men_stripped_first = _step_5b_strip_men(word)
    if men_stripped_first and stem_men_first in KATA_AKAR_SET:
        return stem_men_first

    # Try peN- before suffix stripping, but avoid peN-...-an circumfix here
    if not word.endswith("an"):
        stem_pen_first, pen_stripped_first = _step_5c_strip_pen(word)
        if pen_stripped_first and stem_pen_first in KATA_AKAR_SET:
            return stem_pen_first

    # Step 4: suffixes, then prefixes for circumfixes like peN-...-an
    stem_suf, suf_stripped = _step_4_strip_suffixes(word)
    if suf_stripped:
        if stem_suf in KATA_AKAR_SET:
            return stem_suf
        # After suffix, try meN-, then peN-, then simple prefixes
        stem_men, men_stripped = _step_5b_strip_men(stem_suf)
        if men_stripped and stem_men in KATA_AKAR_SET:
            return stem_men
        stem_pen, pen_stripped = _step_5c_strip_pen(stem_suf)
        if pen_stripped and stem_pen in KATA_AKAR_SET:
            return stem_pen
        stem_pre, pre_stripped = _step_5a_strip_simple_prefixes(stem_suf)
        if pre_stripped and stem_pre in KATA_AKAR_SET:
            return stem_pre

    # Prefix-only path
    stem_pre_only, pre_stripped_only = _step_5a_strip_simple_prefixes(word)
    if pre_stripped_only and stem_pre_only in KATA_AKAR_SET:
        return stem_pre_only

    # Final fallback
    if is_recursive_call:
        return word
    return original_word


# --- 4. Public API ---

def lemma_stem(word: str) -> str:
    """Return lemma-style stem (default for SpaCy lemmatizer)."""
    return _stem_engine(word, mode="lemma", is_recursive_call=False)


def root_stem(word: str) -> str:
    """Return akar kata (root), collapsing productive reduplication."""
    return _stem_engine(word, mode="root", is_recursive_call=False)


# --- 5. Load Lexicon & Exceptions & Tests ---

KATA_AKAR_SET = load_lexicon()
REDUP_EXCEPTIONS = load_redup_exceptions()

if __name__ == "__main__":
    if not KATA_AKAR_SET:
        print("\nStemmer cannot run without lexicon. Exiting.", file=sys.stderr)
        sys.exit(1)

    print("\n--- Running Stemmer Tests (lemma vs root modes, with exceptions hook) ---")

    lemma_tests = {
        # Basic roots
        "makan": "makan",
        "ajar": "ajar",

        # Hyphenated lemmas stay as-is
        "ajar-ajar": "ajar-ajar",
        "buku-buku": "buku-buku",
        "pukul-memukul": "pukul-memukul",
        "berlari-lari": "berlari-lari",

        # Particles
        "makanlah": "makan",
        "siapakah": "siapa",

        # Possessives
        "bukunya": "buku",
        "rumahku": "rumah",
        "bukunyalah": "buku",

        # Suffixes
        "makanan": "makan",
        "gunakan": "guna",
        "usahawan": "usaha",
        "seniman": "seni",
        "wartawati": "warta",

        # meN-
        "membeli": "beli",
        "memukul": "pukul",
        "menutup": "tutup",
        "mencari": "cari",
        "menyapu": "sapu",
        "mengambil": "ambil",
        "mengikat": "ikat",
        "mengkritik": "kritik",

        # peN- / peN-...-an
        "pembangunan": "bangun",
        "penggunaan": "guna",
        "pengguna": "guna",
        "penulis": "tulis",
        "pembaca": "baca",
        "pencari": "cari",
        "pemuda": "pemuda",   # stays as-is
    }

    root_tests = {
        # Roots same as lemma for non-redup forms
        "makan": "makan",
        "membeli": "beli",
        "pembangunan": "bangun",

        # Reduplication collapsed (unless overridden by exceptions file)
        "buku-buku": "buku",
        "ajar-ajar": "ajar",
        "pukul-memukul": "pukul",
        "berlari-lari": "lari",
    }

    passed = 0
    total = len(lemma_tests) + len(root_tests)

    print("\n[ Lemma mode ]")
    for word, expected in lemma_tests.items():
        result = lemma_stem(word)
        if result == expected:
            print(f"✅ lemma_stem('{word}') → '{result}'")
            passed += 1
        else:
            print(f"❌ lemma_stem('{word}') → '{result}' (Expected: '{expected}')")

    print("\n[ Root mode ]")
    for word, expected in root_tests.items():
        result = root_stem(word)
        if result == expected:
            print(f"✅ root_stem('{word}') → '{result}'")
            passed += 1
        else:
            print(f"❌ root_stem('{word}') → '{result}' (Expected: '{expected}')")

    print(f"\n--- {passed} / {total} Tests Passed ---")
    print("\nNOTE: You can now create 'exceptions_redup.txt' (tab-separated) to override")
    print("      root behaviour for specific reduplicated forms.")
