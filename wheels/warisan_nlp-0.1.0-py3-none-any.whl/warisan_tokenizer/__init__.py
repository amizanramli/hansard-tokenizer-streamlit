__version__ = "0.1.0"

from .stemmer import lemma_stem, root_stem